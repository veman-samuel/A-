<?php 
		$sq_base_url='http://localhost/savsoftquiz_v3.0/';
		$sq_hostname='localhost';
		$sq_dbname='';
		$sq_dbusername='root';
		$sq_dbpassword='';
		?>